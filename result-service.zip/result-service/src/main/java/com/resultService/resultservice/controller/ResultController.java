package com.resultService.resultservice.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.resultService.resultservice.model.ResultDetails;
import com.resultService.resultservice.services.AnswerCheckService;

@RestController
public class ResultController {
	
	@Autowired
	private AnswerCheckService answerChkService;
	 
	@RequestMapping(value="/result/answer/save/{sId}/{questionId}/{answer}" , method=RequestMethod.POST)   //to save answer of each question
	public boolean saveAnswers(@PathVariable("sId")int studentId  , @PathVariable("answer")String answer,@PathVariable("questionId") Integer questionId)
	{
		return answerChkService.saveAnswer(studentId, answer,questionId);

	}
	
	@RequestMapping(value="/result/{sId}" , method=RequestMethod.GET)
	public ResultDetails getResult(@PathVariable("sId")int studentId )
	{
		
		return answerChkService.getResult(studentId);
	}
	
	

}
