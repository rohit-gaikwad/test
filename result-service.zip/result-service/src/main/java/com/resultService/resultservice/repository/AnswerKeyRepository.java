package com.resultService.resultservice.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.resultService.resultservice.model.AnswerKey;

@Repository
public interface AnswerKeyRepository extends JpaRepository<AnswerKey, Integer> {

}
