package com.resultService.resultservice.model;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class AnswerKey {

	@Id
	public Integer questionId;
	public String answer;
	
	public AnswerKey() {
		
	}
	
	
	public AnswerKey(Integer questionId, String answer) {
		super();
		this.questionId = questionId;
		this.answer = answer;
	}


	public Integer getQuestionId() {
		return questionId;
	}


	public void setQuestionId(Integer questionId) {
		this.questionId = questionId;
	}


	public String getAnswer() {
		return answer;
	}


	public void setAnswer(String answer) {
		this.answer = answer;
	}
	
	
}
