package com.resultService.resultservice.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.resultService.resultservice.model.AnswerSheet;

@Repository
public interface AnswerSheetRepository extends JpaRepository<AnswerSheet, Integer> {

    public List<AnswerSheet> findBystudentId(Integer studentId);
}
