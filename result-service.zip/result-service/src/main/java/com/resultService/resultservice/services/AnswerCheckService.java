package com.resultService.resultservice.services;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.resultService.resultservice.model.AnswerKey;
import com.resultService.resultservice.model.AnswerSheet;
import com.resultService.resultservice.model.ResultDetails;
import com.resultService.resultservice.repository.AnswerKeyRepository;
import com.resultService.resultservice.repository.AnswerSheetRepository;

@Service
public class AnswerCheckService {
	
	@Autowired
	private AnswerSheetRepository answerSheetRepo;
	
	@Autowired
	private AnswerSheet answerSheet;
	
	@Autowired
	private AnswerKeyRepository answerKeyRepo;
	
	public boolean saveAnswer(int sid,String answer, Integer questionId)   // method to save answer
	{
		answerSheet.setStudentId(sid);
		answerSheet.setAnswer(answer);
		answerSheet.setQuestionId(questionId);
		
		if (answerSheetRepo.save(answerSheet)!=null)
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	
	public ResultDetails getResult(Integer studentId)
	{
		int count=0;
		List<AnswerSheet> ansSheetList = new ArrayList<>();
		List<AnswerKey> ansKeyList = new ArrayList<>();
		ansKeyList= answerKeyRepo.findAll();
		
		Map<Integer, String> ansKeyMap= new HashMap<>();
		for(AnswerKey ansKey: ansKeyList)
		{
			ansKeyMap.put(ansKey.getQuestionId(), ansKey.getAnswer());
			
		}
		
		ansSheetList= answerSheetRepo.findBystudentId(studentId);
		for(AnswerSheet answer:ansSheetList)
		{
			Integer questionId;
			questionId=answer.getQuestionId();
			String questionAnswer= ansKeyMap.get(questionId);
			if(answer.getAnswer().equalsIgnoreCase(questionAnswer))
			{
				count=count+1;
			}
		}
		ResultDetails result =new ResultDetails();
		result.setMarks(count);
		result.setStudentId(studentId);
		
		return result;
		
	}

}
