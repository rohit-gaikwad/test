package com.resultService.resultservice.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

import org.springframework.stereotype.Component;

@Entity
@Component
public class AnswerSheet {
    @Id
    @GeneratedValue
    Integer answerId;
    Integer questionId;
    Integer studentId;
	String answer;
	public Integer getQuestionId() {
		return questionId;
	}

	public void setQuestionId(Integer questionId) {
		this.questionId = questionId;
	}

	
	

	
	
	public Integer getStudentId() {
		return studentId;
	}

	public void setStudentId(Integer studentId) {
		this.studentId = studentId;
	}

	public String getAnswer() {
		return answer;
	}

	public void setAnswer(String answer) {
		this.answer = answer;
	}

	public AnswerSheet() {
		
	}
	
	public AnswerSheet(Integer studentId, String answer) {
		super();
		this.studentId = studentId;
		this.answer = answer;
	}
	
	
	
}
